OLED-UG-2828GDEAF01-Display
===========================

Source code made into a library of the OLED UG-2828GDEAF01 display, found on ebay(very nice)

To use, put this into the directory 
sketchbook/libraries/OLED

restart your arduino, and run the demo.

It's still a work in progress, as I'm playing with adding a characterset. But is functional as is.

